var red = [0, 100, 63];
var orange = [40, 100, 60];
var green = [75, 100, 40];
var blue = [196,77,55];
var purple = [230, 50, 60];

var myName = "0123456789";
letterColors = [red, orange, green, blue,  purple]
if(15 > 5){
	bubbleShape = "circle";

}

else{
	bubbleShape = "square"
}

drawName(myName, letterColors);

bounceBubbles()
